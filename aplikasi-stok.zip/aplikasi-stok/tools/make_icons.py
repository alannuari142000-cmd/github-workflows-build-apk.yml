"""Bikin semua ikon aplikasi (PWA + Android) dari satu desain.

Jalankan:  python3 tools/make_icons.py
Warna gradasi diambil dari header aplikasi (#4f6bed -> #7b5bf0).
"""
import os
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
C1 = (0x4f, 0x6b, 0xed)
C2 = (0x7b, 0x5b, 0xf0)
BIG = 1024  # gambar besar dulu, lalu di-resize biar halus


def gradient(size):
    img = Image.new("RGB", (size, size))
    px = img.load()
    for y in range(size):
        for x in range(size):
            t = (x + y) / (2 * (size - 1))
            px[x, y] = tuple(int(C1[i] + (C2[i] - C1[i]) * t) for i in range(3))
    return img


def cube_layer(size, scale):
    """Kubus (kotak barang) putih di tengah, transparan di sekelilingnya.
    scale = lebar kubus relatif terhadap size."""
    layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx, cy = size / 2, size / 2
    w = size * scale / 2          # setengah lebar kubus
    h = w * 0.58                  # tinggi sisi miring (isometrik)
    s = w * 1.05                  # tinggi sisi tegak
    top = [(cx, cy - s / 2 - h), (cx + w, cy - s / 2), (cx, cy - s / 2 + h), (cx - w, cy - s / 2)]
    left = [(cx - w, cy - s / 2), (cx, cy - s / 2 + h), (cx, cy + s / 2 + h), (cx - w, cy + s / 2)]
    right = [(cx + w, cy - s / 2), (cx, cy - s / 2 + h), (cx, cy + s / 2 + h), (cx + w, cy + s / 2)]
    d.polygon(top, fill=(255, 255, 255, 255))
    d.polygon(left, fill=(226, 230, 250, 255))
    d.polygon(right, fill=(196, 202, 238, 255))
    # garis "lakban" di tutup kubus
    line = max(2, int(size * 0.012))
    d.line([(cx - w / 2, cy - s / 2 - h / 2), (cx + w / 2, cy - s / 2 + h / 2)], fill=(123, 91, 240, 255), width=line * 3)
    return layer


def rounded_mask(size, radius_ratio):
    m = Image.new("L", (size, size), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size - 1, size - 1], radius=int(size * radius_ratio), fill=255)
    return m


def save(img, rel, size):
    path = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.resize((size, size), Image.LANCZOS).save(path, "PNG")


def main():
    bg = gradient(BIG).convert("RGBA")

    # 1) PWA "any": persegi membulat, kubus besar
    any_icon = bg.copy()
    any_icon.alpha_composite(cube_layer(BIG, 0.58))
    any_icon.putalpha(rounded_mask(BIG, 0.22))
    for s in (192, 512):
        save(any_icon, f"www/icons/icon-{s}.png", s)

    # 2) PWA "maskable": penuh sampai tepi, kubus kecil (aman di zona 80%)
    mask_icon = bg.copy()
    mask_icon.alpha_composite(cube_layer(BIG, 0.44))
    save(mask_icon.convert("RGB"), "www/icons/icon-maskable-512.png", 512)

    # 3) Android: ikon lama (legacy) + bulat
    legacy = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
    square = bg.copy()
    square.alpha_composite(cube_layer(BIG, 0.56))
    sq = square.copy()
    sq.putalpha(rounded_mask(BIG, 0.18))
    rd = square.copy()
    rd.putalpha(rounded_mask(BIG, 0.5))
    for dpi, px in legacy.items():
        save(sq, f"android-res/mipmap-{dpi}/ic_launcher.png", px)
        save(rd, f"android-res/mipmap-{dpi}/ic_launcher_round.png", px)

    # 4) Android adaptive: foreground transparan 108dp (kubus di zona aman 66%)
    adaptive = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
    fg = cube_layer(BIG, 0.40)
    for dpi, px in adaptive.items():
        save(fg, f"android-res/mipmap-{dpi}/ic_launcher_foreground.png", px)

    # warna latar adaptive icon
    os.makedirs(os.path.join(ROOT, "android-res/values"), exist_ok=True)
    with open(os.path.join(ROOT, "android-res/values/ic_launcher_background.xml"), "w") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#4F6BED</color>\n</resources>\n')

    # pratinjau besar buat dicek mata
    save(any_icon, "tools/preview-icon.png", 512)
    print("ikon selesai")


if __name__ == "__main__":
    main()
