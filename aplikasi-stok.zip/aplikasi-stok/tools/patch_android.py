"""Dijalankan SETELAH `npx cap add android`.

Kerjanya:
1. Tambah izin kamera di AndroidManifest.xml (supaya scan barcode jalan)
2. Timpa ikon bawaan Capacitor dengan ikon aplikasi (folder android-res/)
"""
import os
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ANDROID = os.path.join(ROOT, "android")
MANIFEST = os.path.join(ANDROID, "app/src/main/AndroidManifest.xml")
RES_SRC = os.path.join(ROOT, "android-res")
RES_DST = os.path.join(ANDROID, "app/src/main/res")

CAMERA_BLOCK = """    <uses-permission android:name="android.permission.CAMERA" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
"""


def patch_manifest():
    if not os.path.isfile(MANIFEST):
        sys.exit("AndroidManifest.xml tidak ditemukan. Jalankan `npx cap add android` dulu.")
    xml = open(MANIFEST, encoding="utf-8").read()
    if "android.permission.CAMERA" in xml:
        print("manifest: izin kamera sudah ada, dilewati")
        return
    internet = re.search(r'^[ \t]*<uses-permission android:name="android\.permission\.INTERNET"\s*/>[ \t]*\n', xml, re.M)
    if not internet:
        sys.exit("Baris izin INTERNET tidak ditemukan di manifest, patch dibatalkan.")
    xml = xml[: internet.end()] + CAMERA_BLOCK + xml[internet.end():]
    open(MANIFEST, "w", encoding="utf-8").write(xml)
    print("manifest: izin kamera ditambahkan")


def copy_icons():
    count = 0
    for folder, _, files in os.walk(RES_SRC):
        rel = os.path.relpath(folder, RES_SRC)
        dst_dir = os.path.join(RES_DST, rel)
        os.makedirs(dst_dir, exist_ok=True)
        for name in files:
            shutil.copy2(os.path.join(folder, name), os.path.join(dst_dir, name))
            count += 1
    print(f"ikon: {count} file disalin")


if __name__ == "__main__":
    patch_manifest()
    copy_icons()
