# Aplikasi Stok → APK

Isi proyek ini sudah siap dijadikan APK. File aplikasimu ada di `www/index.html` (versi terbaru, yang ada kolom nama). Semua library (Firebase, scanner, barcode, PDF) sudah disimpan lokal di `www/lib/`, jadi nggak perlu internet buat memuat skrip.

## Cara 1: APK langsung dari HP (GitHub Actions)

1. Ekstrak zip-nya, lalu upload semua isinya ke repo GitHub baru (bisa pakai plugin Git/Github di Acode).
   Pastikan folder `.github/workflows/build-apk.yml` ikut ke-upload. Kalau gagal, buat manual di GitHub: **Add file → Create new file**, ketik nama `.github/workflows/build-apk.yml`, lalu tempel isi file itu.
2. Buka tab **Actions** → **Build APK** → **Run workflow**.
3. Tunggu sekitar 5–10 menit sampai centang hijau.
4. Buka run-nya, download artifact **aplikasi-stok-apk** (berupa zip), ekstrak, lalu install `app-debug.apk`. Izinkan "install dari sumber tidak dikenal" kalau diminta.

Yang dikerjakan workflow otomatis: pasang plugin Filesystem dan Share, bikin proyek Android, pasang izin kamera, pasang ikon, lalu build.

## Cara 2: PWABuilder (kalau web-nya sudah ada di internet)

1. Taruh isi folder `www/` di hosting (Firebase Hosting, GitHub Pages, Netlify).
2. Buka pwabuilder.com, masukkan URL-nya, pilih Android.
   Manifest dan service worker-nya sudah disiapkan.

## Yang perlu diketahui

- Ini APK **debug**: bisa dipasang di HP sendiri, tapi belum untuk Play Store.
- Di dalam APK, **Download Backup**, **Export PDF**, dan **Cetak / PDF** menyimpan file lewat plugin Filesystem lalu membuka menu Bagikan. Pilih "Simpan ke File/Drive", WhatsApp, atau aplikasi lain. Di versi web, tombol-tombol itu tetap bekerja seperti biasa.
- Scan barcode memakai kamera. Saat pertama dibuka, Android akan minta izin kamera, pilih **Izinkan**.

## Ubah nama, ID, atau ikon

- Nama dan ID aplikasi: `capacitor.config.json` (`appName`, `appId`).
- Ikon: edit warna/gambar di `tools/make_icons.py`, jalankan `python3 tools/make_icons.py`, lalu push lagi.
